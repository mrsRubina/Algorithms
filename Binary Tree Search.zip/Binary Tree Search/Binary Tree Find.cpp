# include <iostream>
# include <cstdlib>
using namespace std;

struct node
{
    int info;
    struct node *left;
    struct node *right;
}*root;
node *root1;

class BST
{
	private:
	 int path[50]; 
    public:
        void insert(node *tree, node *newnode);
        void insert(int);
        void findpath(node*,int,int);
        void getPath(int, node **, node **);    
       //   void find1(node*,int,int);
       // void display(node *, int);
        void display1(node *);
        BST()
        {
            root1 = root = NULL;
        }
};

int main()
{
	char choice;
    int  num,a;
   	int elemnet;
    int array[50]= {8,3,9,11,12,6,1,2,4};
    int array1[50];
      BST bst,bst1;
    node *temp;
    while (1)
    {
       cout<<"\n\n\n             1.Make Tree of Predefined Array "<<endl;
        cout<<"             2.Insert Your own Elements"<<endl;
        cout<<"             3.Find"<<endl;
        cout<<"             4.Exit"<<endl;
        cout<<"             Enter your choice : ";
        cin>>choice;
        switch(choice)
        {
        case '1':
        	for (int i=0;i<9;i++){
		 temp = new node;
            temp->info=array[i];
	        bst.insert(root, temp);
		}
		   cout<<"\n \n             PreDefined array is inserted : \n\n";
		   cout << "        [ ";
         	for (int i=0;i<9;i++){
			 cout << array[i];
			 if(i!=8)
			 cout << " , ";
			 }
			 cout << " ]\n\n";
      	     cout<<"\n             ---------Displaying Binary Tree---------"<<endl;
            bst.display1(root);
        break;
          case '2':
      	int len;
	    cout<<"\n \n             Enter length of  array : ";
	    cin >> len;
	    	for (int i=0;i<len;i++){
		 temp = new node;
           cout<<"Enter the Array elememts "<< i << " : ";
           cin >> array1[i];
            temp->info=array1[i];
	        bst1.insert(root, temp);
		}  cout<<"\n\n             ---------Displaying Binary Tree---------"<<endl;
       	 bst1.display1(root);
	    break;
        case '3':
        	int search;
        	cout << "\n Enter element to be searched ";
        	cin >>elemnet;
     //   	for(int i=0;i<9;i++){
     //   		if(array1)
//			}
        	bst.findpath(root,elemnet,1);
        	 break;
       case '4':
            exit(1);
      
        default:
            cout<<"\n             ---------Wrong choice---------"<<endl;
        }
    }
}
 
void BST::insert(node *tree, node *newnode)
{
    if (root == NULL)
    {
        root = new node;
        root->info = newnode->info;
        root->left = NULL;
        root->right = NULL;
        return;
    }
    if (tree->info == newnode->info)
    {
        return;
    }
    if (tree->info > newnode->info)
    {
        if (tree->left != NULL)
        {
            insert(tree->left, newnode);	
	}
	else
	{
            tree->left = newnode;
            (tree->left)->left = NULL;
            (tree->left)->right = NULL;
            return;
        }
    }
    else
    {
        if (tree->right != NULL)
        {
            insert(tree->right, newnode);
        }
        else
        {
            tree->right = newnode;
            (tree->right)->left = NULL;
            (tree->right)->right = NULL;
            return;
        }	
    }
}
void BST::display1(node *ptr)
{
	
    if (ptr!=NULL){
    	if (ptr->left==NULL && ptr->right==NULL){
		return;
		}else{
    cout << "\n                 Node : "<< ptr->info << " -> L: ";
	if (ptr->left!=NULL){
		cout << ptr->left->info<<" , R: ";
	}else{
		cout << "N , R: ";
	}	
		if (ptr->right!=NULL){
		cout << ptr->right->info;
	}else{
		cout << "N ";
	}
	}
	}else{
		return;
	}
		if(ptr->left==NULL && ptr->right==NULL){
			return;
}else if(ptr->left!=NULL || ptr->right!=NULL){
//		if (ptr->left->left!=NULL && ptr->left->right!=NULL){
		if (ptr->left!=NULL){
			display1(ptr->left);
		    display1(ptr->right);
	}
	else{
//		return;
display1(ptr->right);
	}	
}else{
	return;
}
}

void BST::getPath(int item, node **par, node **loc)
{
//	cout << "\n\n This FIND called : \n\n";
    node *ptr, *ptr1;
    if (root == NULL)
    {
        *loc = NULL;
      //  *par = NULL;
        return;
    }
    if (item == root->info)
    {
        *loc = root;
    //    *par = NULL;
        return;
    }
    if (item < root->info)
        ptr = root->left;
    else
        ptr = root->right;
    ptr1 = root;
    while (ptr != NULL)
    {
        if (item == ptr->info)
        {
            *loc = ptr;
      //      *par = ptr1;
            return;
        }
        ptr1 = ptr;
        if (item < ptr->info)
            ptr = ptr->left;
	else
	    ptr = ptr->right;
    }
    *loc = NULL;
   // *par = ptr1;
}
void BST::findpath(node *tree,int element, int level){
	node *parent, *find;
    getPath(element, &parent, &find);
	if(find==NULL){
		cout << "\n Node not found";
		return;
	}else{
	this->path[level-1]=tree->info;
//	cout << " "<< tree->info;
	  if (root == NULL)
    {
    	cout << "\n Tree is Empty \n";
      //  root = new node;
      //  root->info = newnode->info;
      //  root->left = NULL;
      //  root->right = NULL;
        return;
    }
    if (tree->info == element)
    {
    	cout << "\n It is found \n";
       	cout << "\n Its Level is : "<< level<<" \n";
      // 	for(int i=0;path[i]!="/0")
      int i=0;
        while(path[i]){
        	if(i!=0)
        	cout<< " -> ";
        	cout << path[i];
        	i++;
		}
		return;
    }
    if (tree->info > element)
    {
        if (tree->left != NULL)
        {
            findpath(tree->left,element,level+1);	
	}
	else
	{
          //  tree->left = newnode;
            (tree->left)->left = NULL;
            (tree->left)->right = NULL;
            return;
        }
    }
    else
    {
        if (tree->right != NULL)
        {
            findpath(tree->right,element,level+1);
        }
        else
        {
          //  tree->right = newnode;
            (tree->right)->left = NULL;
            (tree->right)->right = NULL;
            return;
        }	
    }
}
}
/*
void BST::find(node *ptr,int element, int level)
{
    int i;
    if (ptr != NULL)
    {
        display(ptr->right, level+1);
        cout<<endl;
        if (ptr == root)
            cout<<"Root->:  ";
        else
        {
            for (i = 0;i < level;i++)
                cout<<"       ";
	}
        cout<<ptr->info;
        display(ptr->left, level+1);
    }
}*/
